package com.example.cors;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CorsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CorsApplication.class, args);
	}

}
/*
before enabling CORS, if we head into the browser to access http://localhost:8080/test
we won't see the return value, but once we inspect the console we will see
"Access to XMLHttpRequest {127.0.0.1:8080/test} from origin {localhost:8080/test} has been blocked by CORS policy
no 'Access-Control-Allow-Origin' header is present on the requested resource"
 */
