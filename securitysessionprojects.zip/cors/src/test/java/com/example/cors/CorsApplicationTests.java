package com.example.cors;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CorsApplicationTests {

	@Test
	void contextLoads() {
	}

}
