package com.example.csrf.service;

import com.example.csrf.model.Document;
import org.springframework.security.access.prepost.PostFilter;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DocumentService {
    List<Document> documentList;

    public DocumentService() {
        documentList = new ArrayList<>();
    }

    public DocumentService(List<Document> documentList) {
        this.documentList = documentList;
    }

    public Document addDocument(Document document) {
        documentList.add(document);
        return document;
    }

    public Document getDocumentById(Long id) {
        return documentList
                .stream()
                .filter(d -> d.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public Document getDocumentByTitle(String title) {
        return documentList
                .stream()
                .filter(d -> d.getTitle().equals(title))
                .findFirst()
                .orElse(null);
    }


    public List<Document> getAllDocuments() {
        return documentList;
    }
}
