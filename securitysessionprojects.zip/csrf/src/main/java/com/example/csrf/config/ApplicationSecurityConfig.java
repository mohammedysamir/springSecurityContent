package com.example.csrf.config;

import com.example.csrf.config.filter.CsrfTokenFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.csrf.CsrfFilter;
import org.springframework.security.web.csrf.CsrfToken;

import java.util.logging.Logger;

@Configuration
public class ApplicationSecurityConfig {
    Logger logger = Logger.getLogger(ApplicationSecurityConfig.class.getName());

    //csrf
    @Bean("csrf")
    SecurityFilterChain csrfSecurityFilterChain(HttpSecurity http) throws Exception {
        return http
                .httpBasic(Customizer.withDefaults())
                .authorizeHttpRequests(c -> c.anyRequest().permitAll())
                //log csrf token in console
                .addFilterAfter(new CsrfTokenFilter(), CsrfFilter.class)
                .csrf(
                        c -> c
//                                .disable()
//                                .csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse()) //enable XSRF-token in cookies
                                .ignoringRequestMatchers("/ciao") //disable csrf for some paths
                )
                .build();
    }

    //----authentication
    @Bean
    public UserDetailsService userDetailsService() {
        InMemoryUserDetailsManager inMemoryUserDetailsManager = new InMemoryUserDetailsManager();
        inMemoryUserDetailsManager.createUser(
                User.withUsername("Mohammed")
                        .password("12345")
                        .authorities("create", "fetch_one", "fetch_all")
                        .build()
        );

        inMemoryUserDetailsManager.createUser(
                User.withUsername("Youssef")
                        .password("12345")
                        .authorities("create", "fetch_one")
                        .build()
        );

        return inMemoryUserDetailsManager;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return NoOpPasswordEncoder.getInstance();
    }
}
