package com.example.csrf.model;

public class Document{
    Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPayload() {
        return payload;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }

    String title;
    String payload;

    public Document() {
    }

    public Document(Long id, String title, String payload) {
        this.id = id;
        this.title = title;
        this.payload = payload;
    }
}
