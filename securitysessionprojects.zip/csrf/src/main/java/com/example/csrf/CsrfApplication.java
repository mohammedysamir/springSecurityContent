package com.example.csrf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CsrfApplication {

	public static void main(String[] args) {
		SpringApplication.run(CsrfApplication.class, args);
	}

}
