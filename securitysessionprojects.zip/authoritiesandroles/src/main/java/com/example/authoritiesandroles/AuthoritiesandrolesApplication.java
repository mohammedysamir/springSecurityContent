package com.example.authoritiesandroles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthoritiesandrolesApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthoritiesandrolesApplication.class, args);
	}

}
