package com.example.authoritiesandroles.service;

import com.example.authoritiesandroles.model.Document;
import org.springframework.security.access.prepost.PostFilter;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DocumentService {
    List<Document> documentList;

    public DocumentService() {
        documentList = new ArrayList<>();
    }

    public DocumentService(List<Document> documentList) {
        this.documentList = documentList;
    }

    @PreAuthorize("hasAuthority('create')")
    public Document addDocument(Document document) {
        documentList.add(document);
        return document;
    }

    @PreAuthorize("hasAuthority('fetch_one')")
    public Document getDocumentById(Long id) {
        return documentList
                .stream()
                .filter(d -> d.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    @PreAuthorize("hasAuthority('fetch_one')")
    public Document getDocumentByTitle(String title) {
        return documentList
                .stream()
                .filter(d -> d.getTitle().equals(title))
                .findFirst()
                .orElse(null);
    }

    @PreAuthorize("hasAuthority('fetch_all')")
    @PostFilter("!filterObject.title.contains('top secret')")
    public List<Document> getAllDocuments() {
        return documentList;
    }
}
