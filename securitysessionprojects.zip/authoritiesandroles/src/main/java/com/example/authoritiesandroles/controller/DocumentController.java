package com.example.authoritiesandroles.controller;

import com.example.authoritiesandroles.model.Document;
import com.example.authoritiesandroles.service.DocumentService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
public class DocumentController {
    private final DocumentService documentService;

    public DocumentController(@Autowired DocumentService documentService) {
        this.documentService = documentService;
    }

    @GetMapping("/hello")
    public String hello() {
        return "Hello anonymous!";
    }

    //---- document endpoints
    @GetMapping("/documents")
    public ResponseEntity<List<Document>> getDocument(@RequestParam(required = false) Long id, @RequestParam(required = false) String title, HttpServletRequest request) {
        HttpSession session = request.getSession(true);
        List<Document> documents = new ArrayList<>();
        if (null != id) {
            Document documentById = documentService.getDocumentById(id);
            if (null != documentById) {
                documents.add(documentById);
            }
        } else if (null != title && !title.isEmpty()) {
            Document documentByTitle = documentService.getDocumentByTitle(title);
            if (null != documentByTitle) {
                documents.add(documentByTitle);
            }
        } else {
            documents = documentService.getAllDocuments();
        }
        return new ResponseEntity(documents, HttpStatus.OK);
    }

    @PostMapping("/documents")
    public Document createDocument(@RequestBody Document document) {
        return documentService.addDocument(document);
    }
}
