package com.example.authoritiesandroles.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.expression.WebExpressionAuthorizationManager;

import java.util.List;

@Configuration
@EnableMethodSecurity
public class ApplicationConfig {
    //Authorities and Roles
    @Bean
    SecurityFilterChain authoritiesAndRolesSecurityFilterChain(HttpSecurity http) throws Exception {
        return
                http
                        .httpBasic(Customizer.withDefaults())
                        .csrf(AbstractHttpConfigurer::disable)
                        .authorizeHttpRequests(
                                customizer ->
//                                        customizer.anyRequest().permitAll() //permit all

                                //----------------Authority
//                                customizer.requestMatchers("/documents").hasAuthority("fetch_all") //permit only READ-authority users
//                                .anyRequest().permitAll() //permit users with list of authorities

                                //----------------Roles
                                //customizer.anyRequest().hasRole("ADMIN")
                                //customizer.anyRequest().hasAnyRole("ADMIN", "MANAGER")

                                // -------- Combine roles and authorities
                                customizer.requestMatchers("/documents").access(new WebExpressionAuthorizationManager("hasAuthority('create') && !hasRole('ADMIN')"))
                        ).build();
    }

    //----authentication
    @Bean
    public UserDetailsService userDetailsService() {
        InMemoryUserDetailsManager inMemoryUserDetailsManager = new InMemoryUserDetailsManager();

        GrantedAuthority readAuthority = () -> "READ";
        GrantedAuthority writeAuthoirty = new GrantedAuthority() {
            @Override
            public String getAuthority() {
                return "WRITE";
            }
        };

        GrantedAuthority createAuthority = new SimpleGrantedAuthority("HAMADA");

        inMemoryUserDetailsManager.createUser(
                User.withUsername("Mohammed")
                        .password("12345")
                        .authorities("create", "fetch_one", "fetch_all", "ROLE_ADMIN")
                        .build()
        );

        inMemoryUserDetailsManager.createUser(
                User.withUsername("Youssef")
                        .password("12345")
                        .authorities("create", "fetch_one", "ROLE_USER")
                        .build()
        );

        return inMemoryUserDetailsManager;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return NoOpPasswordEncoder.getInstance();
    }
}
