package com.example.authoritiesandroles;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthoritiesandrolesApplicationTests {

	@Test
	void contextLoads() {
	}

}
